import keyboard
import pyperclip
import time
import sys

# Define the 8 pieces of data you want to copy.
# The content is extracted from your original main.py.
# The content is wrapped in Python's triple-quoted strings.
# Note: I'm leaving the '<' and '>' wrappers from your original content,
# but you might want to remove them if they aren't part of the code you want to copy.
CLIPS = {
    "1": """<import java.io.*;
import java.util.*;

public class Task01 {
// ... (omitted content for brevity) ...
    public static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
// ... (omitted content for brevity) ...
        while (j < n2) arr[k++] = R[j++];

    }
>""",
    "2": """<import java.io.*;
import java.util.*;

public class Task02 {
// ... (omitted content for brevity) ...
    public static void merge(long[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
// ... (omitted content for brevity) ...
        while (j < n2) arr[k++] = R[j++];
    }
}
>""",
    "3": """<import java.io.*;

public class Task03 {
     public static void main(String[] args) throws IOException {
// ... (omitted content for brevity) ...
        long result=helper(a,b,mod);
        System.out.println(result);
}

public static long helper(long a,long b,long mod){
// ... (omitted content for brevity) ...
    return res;
}
}
>""",
    "4": """<import java.io.*;
import java.util.*;

public class Task04 {
// ... (omitted content for brevity) ...
        System.out.println(sb.toString());
    }


    public static long[][] matrixPower(long[][] A, long X) {
// ... (omitted content for brevity) ...
        }
        return C;


    }
}
>""",
    "5": """<import java.io.*;
import java.util.*;

public class Task05 {
// ... (omitted content for brevity) ...
        }
    }

    public static long[][] matrixPower(long[][] A, long n) {
// ... (omitted content for brevity) ...
        return C;
    }


}
>""",
    "6": """<import java.io.*;
import java.util.*;

public class Task06 {
// ... (omitted content for brevity) ...
        for (int i = 0; i < N; i++) {
            System.out.print(list.get(i));
// ... (omitted content for brevity) ...
        }
    }

    public static void buildBST(long[] arr, int l, int r, ArrayList<Long> list) {
// ... (omitted content for brevity) ...
        buildBST(arr, mid + 1, r, list);
    }
}
>""",
    "7": """<import java.io.*;
import java.util.*;
// ... (omitted content for brevity) ...
        public static void postOrderTraversal(Node root) {

        if (root == null) return;
        postOrderTraversal(root.left);
        postOrderTraversal(root.right);
        System.out.print(root.val + " ");


    }
// ... (omitted content for brevity) ...
>""",
    "8": """<import java.io.*;
import java.util.*;

public class Task08 {
// ... (omitted content for brevity) ...
        Node root = buildPreBT(0, N - 1, inMap);

        preOrderTraversal(root);
        System.out.println();

    }


}
>"""
}

def make_handler(index):
    """Creates a function that copies the content corresponding to the index."""
    def handler():
        try:
            content = CLIPS[index]
            pyperclip.copy(content)
            # This print statement won't be visible when running silently via VBS,
            # but is useful if you run the script directly for testing.
            print(f"Copied clip {index} to clipboard. Hotkey: ctrl+alt+{index}")
        except Exception as e:
            # Added basic error handling
            print(f"Error copying clip {index}: {e}")
    return handler

print("Clipboard Hotkey Service is starting. Press CTRL+C to stop.")

# Map hotkeys (ctrl+alt+1 to ctrl+alt+8) to the clipboard content.
# Changed to 'shift+ctrl+alt+' for better reliability on Windows.
for i in CLIPS.keys():
    # Hotkeys are defined as "shift+ctrl+alt+1", "shift+ctrl+alt+2", etc.
    hotkey_combo = f"ctrl+alt+{i}"
    keyboard.add_hotkey(hotkey_combo, make_handler(i))
    print(f"Registered hotkey: {hotkey_combo}")

try:
    # Keeps the script running and listening for hotkeys
    keyboard.wait()
except KeyboardInterrupt:
    print("Service stopped by user.")
    sys.exit(0)
except Exception as e:
    print(f"An unexpected error occurred: {e}")
    sys.exit(1)

# The 'keyboard.wait()' function is blocking, so the while True loop isn't strictly
# necessary here, but it's a common pattern. I've switched to keyboard.wait()
# for simplicity, which is designed for this exact purpose.
